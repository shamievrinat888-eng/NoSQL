"""Генерация синтетических данных каталога электроники (детерминированно)."""
import random
from datetime import datetime, timedelta

CATEGORIES = [
    {"_id": "smartphones", "name": "Смартфоны"},
    {"_id": "laptops", "name": "Ноутбуки"},
    {"_id": "headphones", "name": "Наушники"},
    {"_id": "tv", "name": "Телевизоры"},
    {"_id": "smartwatches", "name": "Умные часы"},
    {"_id": "tablets", "name": "Планшеты"},
]

BRANDS = {
    "smartphones": ["Aurora", "Nexa", "Volt", "Zenit"],
    "laptops": ["Aurora", "Nexa", "Kobalt", "Zenit"],
    "headphones": ["Sonic", "Volt", "Nexa", "Pulse"],
    "tv": ["Kobalt", "Zenit", "Lumen", "Aurora"],
    "smartwatches": ["Pulse", "Nexa", "Volt", "Sonic"],
    "tablets": ["Aurora", "Nexa", "Zenit", "Lumen"],
}
PREFIX = {"smartphones": "PHN", "laptops": "LAP", "headphones": "HDP", "tv": "TV",
          "smartwatches": "WCH", "tablets": "TAB"}
SERIES = ["Pro", "Lite", "Max", "Air", "Ultra", "One", "Plus"]
PRICE_RANGE = {  # KZT
    "smartphones": (90_000, 650_000), "laptops": (250_000, 1_400_000),
    "headphones": (12_000, 180_000), "tv": (140_000, 1_100_000),
    "smartwatches": (25_000, 220_000), "tablets": (80_000, 520_000),
}
TAGS = {
    "smartphones": ["5g", "camera", "gaming", "budget"],
    "laptops": ["gaming", "ultrabook", "office", "creator"],
    "headphones": ["wireless", "anc", "sport", "studio"],
    "tv": ["4k", "oled", "smart", "gaming"],
    "smartwatches": ["wireless", "sport", "gps", "kids"],
    "tablets": ["office", "drawing", "wireless", "budget"],
}


def _specs(cat, r):
    if cat == "smartphones":
        return {"ram_gb": r.choice([4, 6, 8, 12]), "storage_gb": r.choice([64, 128, 256, 512]),
                "battery_mah": r.choice([4000, 4500, 5000, 5500, 6000]), "screen_in": round(r.uniform(6.1, 6.9), 1)}
    if cat == "laptops":
        return {"ram_gb": r.choice([8, 16, 32]), "storage_gb": r.choice([256, 512, 1024]),
                "cpu": r.choice(["i5", "i7", "Ryzen 5", "Ryzen 7", "M2"]), "screen_in": r.choice([13.3, 14.0, 15.6, 16.0])}
    if cat == "headphones":
        return {"type": r.choice(["over-ear", "in-ear"]), "anc": r.random() < 0.5, "battery_h": r.randint(20, 60)}
    if cat == "tv":
        return {"diagonal_in": r.choice([43, 50, 55, 65, 75]), "panel": r.choice(["LED", "OLED", "QLED"]), "hdr": r.random() < 0.7}
    if cat == "smartwatches":
        return {"battery_days": r.randint(1, 14), "gps": r.random() < 0.6, "screen_mm": r.choice([40, 42, 44, 46])}
    return {"ram_gb": r.choice([4, 6, 8]), "storage_gb": r.choice([64, 128, 256]), "screen_in": r.choice([8.3, 10.4, 11.0, 12.4])}


def generate_products(n=48, seed=42):
    r = random.Random(seed)
    base = datetime(2026, 1, 1)
    out = []
    for i in range(n):
        cat = CATEGORIES[i % len(CATEGORIES)]["_id"]
        brand = r.choice(BRANDS[cat])
        lo, hi = PRICE_RANGE[cat]
        out.append({
            "sku": f"{PREFIX[cat]}-{i + 1:05d}",
            "name": f"{brand} {r.choice(SERIES)} {r.randint(1, 15)}",
            "brand": brand,
            "category": cat,
            "price": int(round(r.randint(lo, hi), -3)),
            "currency": "KZT",
            "stock": r.choice([0, 1, 2, 3, 5, 8, 12, 20, 35, 60]),
            "rating": round(r.uniform(3.2, 5.0), 1),
            "tags": r.sample(TAGS[cat], 2),
            "specs": _specs(cat, r),
            "created_at": (base + timedelta(days=r.randint(0, 270))).isoformat(),
        })
    return out
