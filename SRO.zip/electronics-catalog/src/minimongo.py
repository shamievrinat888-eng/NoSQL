"""Мини-эмулятор подмножества API pymongo (в памяти).

Нужен ТОЛЬКО для запуска прототипа без установленного MongoDB (CI, быстрый тест).
Поддерживает: insert/find/update/delete/count, create_index (уникальный и
обычный), aggregate ($match, $group, $sort, $limit, $skip, $project, $addFields,
$unwind, $count) и простой планировщик (COLLSCAN / IXSCAN) со счётчиком
docsExamined. Это не замена MongoDB: для итоговых замеров используйте реальный сервер.
"""
import bisect
import copy
import itertools
import re

_MISSING = object()
_ids = itertools.count(1)


class DuplicateKeyError(Exception):
    pass


def _get(doc, path):
    cur = doc
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return _MISSING
    return cur


def _set(doc, path, value):
    parts = path.split(".")
    for p in parts[:-1]:
        doc = doc.setdefault(p, {})
    doc[parts[-1]] = value


def _eq(val, x):
    if val is _MISSING:
        return x is None
    if isinstance(val, list) and not isinstance(x, list):
        return x in val
    return val == x


def _cmp(val, op, arg):
    vals = val if isinstance(val, list) else [val]
    for v in vals:
        try:
            if op == "$gt" and v > arg: return True
            if op == "$gte" and v >= arg: return True
            if op == "$lt" and v < arg: return True
            if op == "$lte" and v <= arg: return True
        except TypeError:
            continue
    return False


def _cond(val, cond):
    if isinstance(cond, dict) and cond and all(k.startswith("$") for k in cond):
        flags = re.I if "i" in cond.get("$options", "") else 0
        for op, arg in cond.items():
            if op == "$options":
                continue
            if op == "$eq":
                ok = _eq(val, arg)
            elif op == "$ne":
                ok = not _eq(val, arg)
            elif op in ("$gt", "$gte", "$lt", "$lte"):
                ok = val is not _MISSING and _cmp(val, op, arg)
            elif op == "$in":
                ok = any(_eq(val, a) for a in arg)
            elif op == "$nin":
                ok = not any(_eq(val, a) for a in arg)
            elif op == "$exists":
                ok = (val is not _MISSING) == bool(arg)
            elif op == "$regex":
                ok = isinstance(val, str) and re.search(arg, val, flags) is not None
            else:
                raise NotImplementedError(op)
            if not ok:
                return False
        return True
    return _eq(val, cond)


def matches(doc, flt):
    for k, c in (flt or {}).items():
        if k == "$and":
            if not all(matches(doc, f) for f in c): return False
        elif k == "$or":
            if not any(matches(doc, f) for f in c): return False
        elif not _cond(_get(doc, k), c):
            return False
    return True


def _expr(doc, e):
    if isinstance(e, str) and e.startswith("$"):
        v = _get(doc, e[1:])
        return None if v is _MISSING else v
    if isinstance(e, dict) and len(e) == 1:
        (op, a), = e.items()
        if op == "$multiply":
            r = 1
            for x in a: r *= _expr(doc, x)
            return r
        if op == "$add": return sum(_expr(doc, x) for x in a)
        if op == "$subtract": return _expr(doc, a[0]) - _expr(doc, a[1])
        if op == "$size": return len(_expr(doc, a))
        if op == "$round": return round(_expr(doc, a[0]), a[1] if len(a) > 1 else 0)
    return e


def _sort_docs(docs, spec):
    items = list(spec.items()) if isinstance(spec, dict) else list(spec)
    for key, direction in reversed(items):
        def k(d, key=key):
            v = _get(d, key)
            return (v is _MISSING or v is None, 0 if v is _MISSING or v is None else v)
        docs.sort(key=k, reverse=(direction == -1))
    return docs


def _project(doc, proj):
    inc = {k for k, v in proj.items() if v and not isinstance(v, (dict, str)) and k != "_id"}
    if inc:
        out = {k: copy.deepcopy(_get(doc, k)) for k in inc if _get(doc, k) is not _MISSING}
        if proj.get("_id", 1): out["_id"] = doc.get("_id")
        return out
    out = copy.deepcopy(doc)
    for k, v in proj.items():
        if not v: out.pop(k, None)
    return out


class Cursor:
    def __init__(self, coll, flt, proj=None):
        self.coll, self.flt, self.proj = coll, flt or {}, proj
        self._sort = self._limit = None
        self._skip = 0

    def sort(self, key, direction=1):
        self._sort = [(key, direction)] if isinstance(key, str) else list(key)
        return self

    def limit(self, n):
        self._limit = n; return self

    def skip(self, n):
        self._skip = n; return self

    def _run(self):
        cand, plan = self.coll._plan(self.flt)
        docs = [d for d in cand if matches(d, self.flt)]
        self.stats = {"stage": plan["stage"], "indexName": plan.get("indexName"),
                      "docsExamined": len(cand), "nReturned": len(docs)}
        if self._sort: _sort_docs(docs, self._sort)
        docs = docs[self._skip:]
        if self._limit: docs = docs[:self._limit]
        return [_project(d, self.proj) if self.proj else copy.deepcopy(d) for d in docs]

    def explain(self):
        self._run()
        return dict(self.stats)

    def __iter__(self):
        return iter(self._run())


class Result:
    def __init__(self, **kw): self.__dict__.update(kw)


class Collection:
    def __init__(self, name):
        self.name, self.docs, self.indexes, self._cache = name, [], {}, {}

    # --- индексы ---
    def create_index(self, keys, unique=False, name=None):
        keys = [(keys, 1)] if isinstance(keys, str) else list(keys)
        name = name or "_".join(f"{k}_{d}" for k, d in keys)
        self.indexes[name] = {"keys": keys, "unique": unique}
        self._cache.pop(name, None)
        return name

    def drop_index(self, name):
        self.indexes.pop(name, None); self._cache.pop(name, None)

    def index_information(self):
        return {n: {"key": i["keys"], "unique": i["unique"]} for n, i in self.indexes.items()}

    def _index(self, name):
        if name not in self._cache:
            f = self.indexes[name]["keys"][0][0]
            pairs = sorted(((_get(d, f), i) for i, d in enumerate(self.docs)
                            if _get(d, f) is not _MISSING and not isinstance(_get(d, f), list)),
                           key=lambda p: p[0])
            self._cache[name] = ([p[0] for p in pairs], [p[1] for p in pairs])
        return self._cache[name]

    def _plan(self, flt):
        best = None
        for name, info in self.indexes.items():
            f = info["keys"][0][0]
            c = (flt or {}).get(f, _MISSING)
            if c is _MISSING:
                continue
            if isinstance(c, dict) and not any(k in c for k in ("$gt", "$gte", "$lt", "$lte", "$eq")):
                continue
            try:
                vals, pos = self._index(name)
                lo, hi = 0, len(vals)
                if isinstance(c, dict) and "$eq" in c:
                    c = c["$eq"]
                if isinstance(c, dict):
                    if "$gte" in c: lo = max(lo, bisect.bisect_left(vals, c["$gte"]))
                    if "$gt" in c: lo = max(lo, bisect.bisect_right(vals, c["$gt"]))
                    if "$lte" in c: hi = min(hi, bisect.bisect_right(vals, c["$lte"]))
                    if "$lt" in c: hi = min(hi, bisect.bisect_left(vals, c["$lt"]))
                else:
                    lo, hi = bisect.bisect_left(vals, c), bisect.bisect_right(vals, c)
                ids = pos[lo:hi]
            except TypeError:
                continue
            if best is None or len(ids) < len(best[0]):
                best = (ids, name)
        if best:
            return [self.docs[i] for i in sorted(best[0])], {"stage": "IXSCAN", "indexName": best[1]}
        return self.docs, {"stage": "COLLSCAN"}

    def _dirty(self):
        self._cache.clear()

    # --- CRUD ---
    def _check_unique(self, doc, skip=None):
        for name, info in self.indexes.items():
            if info["unique"]:
                f = info["keys"][0][0]
                v = _get(doc, f)
                if v is not _MISSING and any(d is not skip and _get(d, f) == v for d in self.docs):
                    raise DuplicateKeyError(f"E11000 duplicate key error: {name} dup key: {v!r}")

    def insert_one(self, doc):
        doc = copy.deepcopy(doc)
        doc.setdefault("_id", f"oid{next(_ids):08d}")
        self._check_unique(doc)
        self.docs.append(doc); self._dirty()
        return Result(inserted_id=doc["_id"])

    def insert_many(self, docs):
        ids = [self.insert_one(d).inserted_id for d in docs]
        return Result(inserted_ids=ids)

    def find(self, flt=None, projection=None):
        return Cursor(self, flt, projection)

    def find_one(self, flt=None, projection=None):
        r = list(Cursor(self, flt, projection).limit(1))
        return r[0] if r else None

    def count_documents(self, flt=None):
        return sum(1 for d in self.docs if matches(d, flt or {}))

    def _apply(self, d, upd):
        for op, fields in upd.items():
            for k, v in fields.items():
                if op == "$set": _set(d, k, v)
                elif op == "$inc":
                    cur = _get(d, k); _set(d, k, (0 if cur is _MISSING else cur) + v)
                elif op == "$unset":
                    d.pop(k, None)
                else: raise NotImplementedError(op)

    def update_one(self, flt, upd, upsert=False):
        for d in self.docs:
            if matches(d, flt):
                before = copy.deepcopy(d)
                self._apply(d, upd)
                self._check_unique(d, skip=d)
                self._dirty()
                return Result(matched_count=1, modified_count=int(before != d))
        return Result(matched_count=0, modified_count=0)

    def update_many(self, flt, upd):
        n = 0
        for d in self.docs:
            if matches(d, flt): self._apply(d, upd); n += 1
        self._dirty()
        return Result(matched_count=n, modified_count=n)

    def delete_one(self, flt):
        for i, d in enumerate(self.docs):
            if matches(d, flt):
                del self.docs[i]; self._dirty(); return Result(deleted_count=1)
        return Result(deleted_count=0)

    def delete_many(self, flt):
        keep = [d for d in self.docs if not matches(d, flt)]
        n = len(self.docs) - len(keep); self.docs[:] = keep; self._dirty()
        return Result(deleted_count=n)

    # --- агрегации ---
    def aggregate(self, pipeline):
        docs = [copy.deepcopy(d) for d in self.docs]
        for stage in pipeline:
            (op, arg), = stage.items()
            if op == "$match":
                docs = [d for d in docs if matches(d, arg)]
            elif op == "$sort":
                _sort_docs(docs, arg)
            elif op == "$limit":
                docs = docs[:arg]
            elif op == "$skip":
                docs = docs[arg:]
            elif op == "$count":
                docs = [{arg: len(docs)}]
            elif op == "$unwind":
                path = (arg if isinstance(arg, str) else arg["path"])[1:]
                out = []
                for d in docs:
                    v = _get(d, path)
                    if isinstance(v, list):
                        for x in v:
                            n = copy.deepcopy(d); _set(n, path, x); out.append(n)
                docs = out
            elif op in ("$project", "$addFields", "$set"):
                out = []
                for d in docs:
                    n = copy.deepcopy(d) if op != "$project" else {}
                    if op == "$project" and arg.get("_id", 1): n["_id"] = d.get("_id")
                    for k, v in arg.items():
                        if k == "_id" and op == "$project": continue
                        if op == "$project" and (v == 1 or v is True):
                            x = _get(d, k)
                            if x is not _MISSING: _set(n, k, x)
                        elif op == "$project" and v == 0:
                            continue
                        else:
                            _set(n, k, _expr(d, v))
                    out.append(n)
                docs = out
            elif op == "$group":
                groups = {}
                for d in docs:
                    key = _expr(d, arg["_id"]) if arg["_id"] is not None else None
                    groups.setdefault(key, []).append(d)
                out = []
                for key, items in groups.items():
                    g = {"_id": key}
                    for f, spec in arg.items():
                        if f == "_id": continue
                        (acc, e), = spec.items()
                        vals = [_expr(d, e) for d in items]
                        nums = [v for v in vals if v is not None]
                        if acc == "$sum": g[f] = sum(nums)
                        elif acc == "$avg": g[f] = sum(nums) / len(nums) if nums else None
                        elif acc == "$min": g[f] = min(nums) if nums else None
                        elif acc == "$max": g[f] = max(nums) if nums else None
                        elif acc == "$first": g[f] = vals[0]
                        elif acc == "$push": g[f] = vals
                        else: raise NotImplementedError(acc)
                    out.append(g)
                docs = out
            else:
                raise NotImplementedError(op)
        return docs


class Database:
    def __init__(self, name):
        self.name, self._c = name, {}

    def __getitem__(self, n):
        return self._c.setdefault(n, Collection(n))

    def __getattr__(self, n):
        if n.startswith("_"): raise AttributeError(n)
        return self[n]

    def list_collection_names(self):
        return list(self._c)


class MiniClient:
    def __init__(self):
        self._d = {}

    def __getitem__(self, n):
        return self._d.setdefault(n, Database(n))

    def drop_database(self, n):
        self._d.pop(n, None)
