"""Подключение к БД: реальный MongoDB (pymongo) или встроенный эмулятор."""
import os

from dotenv import load_dotenv

load_dotenv()


def get_db(backend=None):
    """Возвращает (db, backend_name). DB_BACKEND: auto | mongo | emulator."""
    backend = backend or os.getenv("DB_BACKEND", "auto")
    uri = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    name = os.getenv("MONGO_DB", "electronics_catalog")
    if backend in ("auto", "mongo"):
        try:
            import pymongo
            client = pymongo.MongoClient(uri, serverSelectionTimeoutMS=2000)
            client.admin.command("ping")
            return client[name], "mongodb"
        except Exception:
            if backend == "mongo":
                raise
    from src.minimongo import MiniClient
    return MiniClient()[name], "emulator"


def explain_summary(cursor):
    """Единый вид explain() для pymongo и эмулятора."""
    e = cursor.explain()
    if "executionStats" in e:
        st = e["executionStats"]
        plan = e["queryPlanner"]["winningPlan"]
        while "inputStage" in plan:
            plan = plan["inputStage"]
        return {"stage": plan.get("stage"), "indexName": plan.get("indexName"),
                "docsExamined": st["totalDocsExamined"], "nReturned": st["nReturned"]}
    return e
