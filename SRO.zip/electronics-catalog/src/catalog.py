"""Слой доступа к данным: CRUD + индексы (MongoDB / эмулятор)."""
from src.seed_data import CATEGORIES, generate_products


class ValidationError(ValueError):
    pass


REQUIRED = ("sku", "name", "brand", "category", "price", "stock")


def validate_product(p):
    for f in REQUIRED:
        if f not in p:
            raise ValidationError(f"нет обязательного поля: {f}")
    if not isinstance(p["price"], (int, float)) or p["price"] <= 0:
        raise ValidationError("price должен быть > 0")
    if not isinstance(p["stock"], int) or p["stock"] < 0:
        raise ValidationError("stock должен быть целым >= 0")
    return p


class Catalog:
    def __init__(self, db):
        self.db = db
        self.products = db["products"]
        self.categories = db["categories"]

    # --- индексы ---
    def setup_indexes(self):
        self.products.create_index("sku", unique=True)
        self.products.create_index([("category", 1), ("price", 1)])
        self.products.create_index("price")
        self.products.create_index("stock")

    # --- Create ---
    def seed(self, n=48):
        if self.categories.count_documents({}) == 0:
            self.categories.insert_many(CATEGORIES)
        self.products.insert_many(generate_products(n))
        return self.products.count_documents({})

    def add_product(self, product):
        validate_product(product)
        return self.products.insert_one(product).inserted_id

    # --- Read ---
    def get_by_sku(self, sku):
        return self.products.find_one({"sku": sku})

    def list_by_category(self, category, limit=10):
        return list(self.products.find({"category": category}).sort("price", 1).limit(limit))

    # --- Update ---
    def update_price(self, sku, new_price):
        if new_price <= 0:
            raise ValidationError("price должен быть > 0")
        return self.products.update_one({"sku": sku}, {"$set": {"price": new_price}}).modified_count

    def adjust_stock(self, sku, delta):
        p = self.get_by_sku(sku)
        if p is None:
            return 0
        if p["stock"] + delta < 0:
            raise ValidationError("остаток не может быть отрицательным")
        return self.products.update_one({"sku": sku}, {"$inc": {"stock": delta}}).modified_count

    # --- Delete ---
    def delete_product(self, sku):
        return self.products.delete_one({"sku": sku}).deleted_count
