"""8 демонстрационных запросов (Access Patterns AP1–AP8)."""

QUERIES = [
    {"id": "Q1", "ap": "AP1", "title": "Смартфоны в диапазоне цены, по возрастанию цены",
     "shell": 'find({category:"smartphones", price:{$gte:150000,$lte:400000}}).sort({price:1})',
     "run": lambda db: list(db.products.find(
         {"category": "smartphones", "price": {"$gte": 150_000, "$lte": 400_000}}).sort("price", 1))},
    {"id": "Q2", "ap": "AP2", "title": "Фильтр по характеристикам: RAM>=8 ГБ и батарея>=5000 мАч",
     "shell": 'find({category:"smartphones","specs.ram_gb":{$gte:8},"specs.battery_mah":{$gte:5000}})',
     "run": lambda db: list(db.products.find(
         {"category": "smartphones", "specs.ram_gb": {"$gte": 8}, "specs.battery_mah": {"$gte": 5000}}))},
    {"id": "Q3", "ap": "AP3", "title": "Поиск по части названия (regex, без регистра)",
     "shell": 'find({name:{$regex:"pro",$options:"i"}}).limit(10)',
     "run": lambda db: list(db.products.find({"name": {"$regex": "pro", "$options": "i"}}).limit(10))},
    {"id": "Q4", "ap": "AP4", "title": "Агрегация: средняя цена по категориям",
     "shell": 'aggregate([{$group:{_id:"$category",avg_price:{$avg:"$price"},n:{$sum:1}}},{$sort:{avg_price:-1}}])',
     "run": lambda db: db.products.aggregate([
         {"$group": {"_id": "$category", "avg_price": {"$avg": "$price"}, "n": {"$sum": 1}}},
         {"$project": {"avg_price": {"$round": ["$avg_price", 0]}, "n": 1}},
         {"$sort": {"avg_price": -1}}])},
    {"id": "Q5", "ap": "AP5", "title": "Нетривиально: топ брендов по среднему рейтингу (>=3 товара)",
     "shell": 'aggregate([{$group:{_id:"$brand",avg_rating:{$avg:"$rating"},n:{$sum:1}}},{$match:{n:{$gte:3}}},{$sort:{avg_rating:-1}},{$limit:5}])',
     "run": lambda db: db.products.aggregate([
         {"$group": {"_id": "$brand", "avg_rating": {"$avg": "$rating"}, "n": {"$sum": 1}}},
         {"$match": {"n": {"$gte": 3}}},
         {"$project": {"avg_rating": {"$round": ["$avg_rating", 2]}, "n": 1}},
         {"$sort": {"avg_rating": -1}}, {"$limit": 5}])},
    {"id": "Q6", "ap": "AP6", "title": "Нетривиально: стоимость складских остатков по брендам",
     "shell": 'aggregate([{$group:{_id:"$brand",stock_value:{$sum:{$multiply:["$price","$stock"]}}}},{$sort:{stock_value:-1}},{$limit:5}])',
     "run": lambda db: db.products.aggregate([
         {"$group": {"_id": "$brand", "stock_value": {"$sum": {"$multiply": ["$price", "$stock"]}},
                     "items": {"$sum": 1}}},
         {"$sort": {"stock_value": -1}}, {"$limit": 5}])},
    {"id": "Q7", "ap": "AP7", "title": "Товары в наличии с тегами wireless/gaming, по рейтингу",
     "shell": 'find({tags:{$in:["wireless","gaming"]},stock:{$gt:0}}).sort({rating:-1}).limit(8)',
     "run": lambda db: list(db.products.find(
         {"tags": {"$in": ["wireless", "gaming"]}, "stock": {"$gt": 0}}).sort("rating", -1).limit(8))},
    {"id": "Q8", "ap": "AP8", "title": "Заканчивающиеся товары (остаток <= 3), по остатку",
     "shell": 'find({stock:{$lte:3}}).sort({stock:1,price:-1})',
     "run": lambda db: list(db.products.find({"stock": {"$lte": 3}}).sort([("stock", 1), ("price", -1)]))},
]
