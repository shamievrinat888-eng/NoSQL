# Каталог электроники с быстрым поиском (MongoDB)

СРО по дисциплине «Проектирование и применение NoSQL-технологий», **вариант 1**.
Карточки товаров, категории, фильтрация по цене и характеристикам, агрегация средней цены, сравнение запросов до и после индекса.

## Структура
```
src/            catalog.py (CRUD, валидация), queries.py (8 запросов), seed_data.py, db.py, minimongo.py (эмулятор)
scripts/        seed.py, run_queries.py, demo_crud.py, bench_index.py, make_docs_assets.py, build_report.py
tests/          test_catalog.py (7 тестов, unittest)
docs/           ADR.md, architecture.png, data_model.png, screenshots/, report.pdf, presentation.pptx / .pdf
.env.example    переменные окружения (без секретов)
```

## Запуск
```bash
pip install -r requirements.txt
cp .env.example .env
# Вариант А — реальный MongoDB:
docker run -d --name mongo -p 27017:27017 mongo:7
DB_BACKEND=mongo python scripts/seed.py
# Вариант Б — без сервера (встроенный эмулятор, для быстрой проверки):
DB_BACKEND=emulator python scripts/seed.py
python scripts/run_queries.py      # 8 запросов
python scripts/demo_crud.py        # Create/Read/Update/Delete
python scripts/bench_index.py 20000  # до/после индекса
python -m unittest discover -s tests -v
```
`DB_BACKEND=auto` (по умолчанию) использует MongoDB, если он доступен, иначе эмулятор.

## Важно
Эмулятор `src/minimongo.py` реализует лишь подмножество API pymongo и свой простой планировщик; он нужен для тестов без сервера.
Итоговые замеры производительности для защиты следует повторить на реальном MongoDB (`DB_BACKEND=mongo`).

## Ссылки
Отчёт: `docs/report.pdf` · Презентация: `docs/presentation.pdf` · ADR: `docs/ADR.md`
