"""Генерирует скриншоты терминала (из РЕАЛЬНОГО вывода скриптов) и диаграммы для docs/."""
import os, subprocess, sys, json
from PIL import Image, ImageDraw, ImageFont
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHOTS = os.path.join(ROOT, "docs", "screenshots")
os.makedirs(SHOTS, exist_ok=True)
env = dict(os.environ, DB_BACKEND="emulator", PYTHONIOENCODING="utf-8")
MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
MONOB = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"


def run(cmd):
    r = subprocess.run(cmd, shell=True, cwd=ROOT, env=env, capture_output=True, text=True)
    return (r.stdout + r.stderr).rstrip("\n")


def wrap(line, n=132):
    out = []
    while len(line) > n:
        out.append(line[:n]); line = "      " + line[n:]
    return out + [line]


def terminal(name, cmd, text, title="bash — electronics-catalog", fs=15, w=1320, cols=132):
    f, fb = ImageFont.truetype(MONO, fs), ImageFont.truetype(MONOB, fs)
    lines = ["$ " + cmd, ""]
    for l in text.split("\n"):
        lines += wrap(l, cols)
    lh, pad, top = int(fs * 1.47), 22, 44
    h = top + pad * 2 + lh * len(lines)
    img = Image.new("RGB", (w, h), "#1e1e2e")
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, w, top - 8], fill="#313244")
    for i, c in enumerate(["#f38ba8", "#f9e2af", "#a6e3a1"]):
        d.ellipse([16 + i * 24, 12, 30 + i * 24, 26], fill=c)
    d.text((w // 2 - 120, 10), title, fill="#a6adc8", font=f)
    y = top + pad - 8
    for i, l in enumerate(lines):
        col, font = "#cdd6f4", f
        if i == 0: col, font = "#a6e3a1", fb
        elif l.startswith("[Q"): col, font = "#f9e2af", fb
        elif l.strip().startswith("->"): col = "#89dceb"
        elif l.strip().startswith("db.products"): col = "#b4befe"
        elif l.endswith("ok") or l == "OK": col = "#a6e3a1"
        elif l.startswith(("backend", "ускорение")): col, font = "#fab387", fb
        d.text((pad, y), l, fill=col, font=font)
        y += lh
    img.save(os.path.join(SHOTS, name))
    return os.path.join(SHOTS, name)


def box(ax, x, y, w, h, text, fc, ec="#333", fs=10, dashed=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08", fc=fc, ec=ec,
                                lw=1.5, ls="--" if dashed else "-"))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs)


def arrow(ax, a, b, label=""):
    ax.annotate("", xy=b, xytext=a, arrowprops=dict(arrowstyle="->", lw=1.6, color="#444"))
    if label:
        ax.text((a[0] + b[0]) / 2, (a[1] + b[1]) / 2 + 0.12, label, ha="center", fontsize=8, color="#444")


def architecture():
    fig, ax = plt.subplots(figsize=(11, 5.2)); ax.set_xlim(0, 11); ax.set_ylim(0, 5.2); ax.axis("off")
    box(ax, 0.2, 2.0, 2.1, 1.2, "Пользователь /\nCLI-скрипты\n(seed, queries, demo)", "#dbeafe")
    box(ax, 3.1, 1.6, 2.6, 2.0, "Python-приложение\n\ncatalog.py (CRUD,\nвалидация)\nqueries.py (8 запросов)", "#dcfce7")
    box(ax, 6.5, 3.2, 2.3, 1.2, "pymongo\n(драйвер)", "#fef9c3")
    box(ax, 6.5, 0.8, 2.3, 1.2, "minimongo.py\n(эмулятор для тестов)", "#f3f4f6", dashed=True)
    box(ax, 9.3, 2.6, 1.6, 2.4, "MongoDB\n:27017\n\ncategories\nproducts\n+ индексы", "#fee2e2")
    arrow(ax, (2.3, 2.6), (3.1, 2.6), "вызовы")
    arrow(ax, (5.7, 3.0), (6.5, 3.7), "")
    arrow(ax, (5.7, 2.2), (6.5, 1.4), "")
    ax.text(4.4, 1.25, "DB_BACKEND=emulator", ha="center", fontsize=8, color="#444")
    arrow(ax, (8.8, 3.8), (9.3, 3.8), "")
    ax.text(5.5, 5.0, "Архитектура прототипа: каталог электроники", ha="center", fontsize=13, weight="bold")
    ax.text(5.5, 0.15, "Основной режим — MongoDB через pymongo; эмулятор — запасной режим без сервера (тесты/CI)", ha="center", fontsize=9, color="#555")
    fig.savefig(os.path.join(ROOT, "docs", "architecture.png"), dpi=150, bbox_inches="tight"); plt.close(fig)


def schema():
    fig, ax = plt.subplots(figsize=(11, 5.4)); ax.set_xlim(0, 11); ax.set_ylim(0, 5.4); ax.axis("off")
    ax.text(5.5, 5.15, "Модель данных: referencing (category) + embedding (specs, tags)", ha="center", fontsize=13, weight="bold")
    box(ax, 0.3, 3.2, 2.6, 1.4, "categories\n_id: \"smartphones\"\nname: \"Смартфоны\"", "#dbeafe", fs=10)
    prod = ("products\n_id, sku (unique)\nname, brand, price (KZT)\nstock, rating, created_at\ncategory → categories._id\ntags: [\"5g\",\"gaming\"]   (embedded)\n"
            "specs: {ram_gb, storage_gb,\n          battery_mah, ...}   (embedded)")
    box(ax, 4.2, 1.2, 4.0, 3.4, prod, "#dcfce7", fs=10)
    arrow(ax, (2.9, 3.9), (4.2, 3.9), "1 : N")
    box(ax, 8.9, 3.2, 2.0, 1.4, "Индексы\nsku (unique)\n{category, price}\nprice, stock", "#fef9c3", fs=9)
    arrow(ax, (8.2, 3.9), (8.9, 3.9), "")
    ax.text(5.5, 0.55, "specs различаются по категориям (polymorphic pattern) — схема гибкая, JOIN не нужны", ha="center", fontsize=9, color="#555")
    fig.savefig(os.path.join(ROOT, "docs", "data_model.png"), dpi=150, bbox_inches="tight"); plt.close(fig)


def bench_chart():
    r = json.load(open(os.path.join(ROOT, "docs", "bench_result.json")))
    fig, axs = plt.subplots(1, 2, figsize=(9, 3.6))
    labels = ["без индекса\n(COLLSCAN)", "с индексом\n(IXSCAN)"]
    for ax, key, title in ((axs[0], "docsExamined", "Просмотрено документов"), (axs[1], "avg_ms", "Среднее время, мс")):
        vals = [r["before"][key], r["after"][key]]
        bars = ax.bar(labels, vals, color=["#ef4444", "#22c55e"])
        ax.set_title(title, fontsize=11)
        for b, v in zip(bars, vals): ax.text(b.get_x() + b.get_width() / 2, v, f"{v:,}", ha="center", va="bottom", fontsize=10)
        ax.spines[["top", "right"]].set_visible(False)
    fig.suptitle(f"Запрос по диапазону price, {r['n']:,} документов ({r['backend']})", fontsize=11)
    fig.tight_layout(); fig.savefig(os.path.join(ROOT, "docs", "bench_chart.png"), dpi=150); plt.close(fig)


if __name__ == "__main__":
    out = {}
    out["seed"] = run("python scripts/seed.py")
    terminal("01_seed.png", "python scripts/seed.py", out["seed"])
    q = run("python scripts/run_queries.py")
    head, *blocks = q.split("\n\n")
    blocks = [b for b in blocks if b.strip()]
    terminal("02_queries_q1_q4.png", "python scripts/run_queries.py   # Q1–Q4", head + "\n\n" + "\n\n".join(blocks[:4]))
    terminal("03_queries_q5_q8.png", "python scripts/run_queries.py   # Q5–Q8", "\n\n".join(blocks[4:]))
    terminal("04_crud.png", "python scripts/demo_crud.py", run("python scripts/demo_crud.py"))
    terminal("05_tests.png", "python -m unittest discover -s tests -v", run("python -m unittest discover -s tests -v"))
    terminal("06_bench.png", "python scripts/bench_index.py 20000", run("python scripts/bench_index.py 20000"))
    import re
    blk = [b for b in blocks]
    short = []
    for b in (blk[0], blk[3], blk[4]):
        ls = b.split("\n")
        short.append("\n".join(ls[:2] + [ls[2]] + ls[3:6]))
    shell_hide = lambda t: "\n".join(l for l in t.split("\n") if not l.strip().startswith("db.products"))
    terminal("s_queries.png", "python scripts/run_queries.py", "backend: emulator   products: 48\n\n" + shell_hide("\n\n".join(short)), fs=20, w=1100, cols=78)
    t = re.sub(r" \(test_catalog\.CatalogTests\.\w+\)", "", run("python -m unittest discover -s tests -v"))
    terminal("s_tests.png", "python -m unittest discover -s tests -v", t, fs=18, w=1100, cols=78)
    terminal("s_crud.png", "python scripts/demo_crud.py", run("python scripts/demo_crud.py"), fs=19, w=1100, cols=78)
    architecture(); schema(); bench_chart()
    print("assets ok:", sorted(os.listdir(SHOTS)))
