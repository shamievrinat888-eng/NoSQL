"""Сравнение запроса до/после индекса: python scripts/bench_index.py [N]
Выводит docsExamined и среднее время; результат сохраняется в docs/bench_result.json."""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.db import get_db, explain_summary
from src.seed_data import CATEGORIES, generate_products

N = int(sys.argv[1]) if len(sys.argv) > 1 else 20000
db, backend = get_db()
p = db["products"]; p.delete_many({})
p.insert_many(generate_products(N, seed=7))
flt = {"price": {"$gte": 300_000, "$lte": 310_000}}


def measure(label):
    t = time.perf_counter()
    for _ in range(20):
        n = len(list(p.find(flt)))
    ms = (time.perf_counter() - t) / 20 * 1000
    ex = explain_summary(p.find(flt))
    print(f"{label:<14} stage={ex['stage']:<9} docsExamined={ex['docsExamined']:<6} nReturned={ex['nReturned']:<4} avg={ms:7.2f} ms")
    return {"stage": ex["stage"], "docsExamined": ex["docsExamined"], "nReturned": ex["nReturned"], "avg_ms": round(ms, 2)}


print(f"backend: {backend}   documents: {N}")
print(f"query: db.products.find({json.dumps(flt)})")
before = measure("БЕЗ индекса")
p.create_index("price")
after = measure("С индексом")
print(f"ускорение: x{before['avg_ms'] / max(after['avg_ms'], 0.001):.1f}; просмотрено документов: {before['docsExamined']} -> {after['docsExamined']}")
out = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs", "bench_result.json")
json.dump({"backend": backend, "n": N, "before": before, "after": after}, open(out, "w"), indent=2)
