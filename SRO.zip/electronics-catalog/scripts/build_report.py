"""Сборка docs/report.pdf (reportlab)."""
import json, os
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, Preformatted, KeepTogether)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
D = os.path.join(ROOT, "docs")
F = "/usr/share/fonts/truetype/dejavu/"
pdfmetrics.registerFont(TTFont("DV", F + "DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DVB", F + "DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("DVM", F + "DejaVuSansMono.ttf"))
body = ParagraphStyle("b", fontName="DV", fontSize=10, leading=14.5, alignment=TA_JUSTIFY, spaceAfter=6)
h1 = ParagraphStyle("h1", fontName="DVB", fontSize=15, leading=19, spaceBefore=10, spaceAfter=8, textColor=colors.HexColor("#14532d"))
h2 = ParagraphStyle("h2", fontName="DVB", fontSize=11.5, leading=15, spaceBefore=6, spaceAfter=4)
cell = ParagraphStyle("c", fontName="DV", fontSize=8.6, leading=11)
cellb = ParagraphStyle("cb", parent=cell, fontName="DVB", textColor=colors.white)
cap = ParagraphStyle("cap", fontName="DV", fontSize=8.5, leading=11, alignment=TA_CENTER, textColor=colors.HexColor("#555"), spaceAfter=8)
code = ParagraphStyle("code", fontName="DVM", fontSize=7.6, leading=9.6, backColor=colors.HexColor("#f3f4f6"), borderPadding=5, spaceAfter=8)
P = lambda t, s=body: Paragraph(t, s)


def table(rows, widths, head=True):
    data = [[P(str(c), cellb if (head and i == 0) else cell) for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=[w * cm for w in widths], repeatRows=1 if head else 0)
    st = [("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#9ca3af")), ("VALIGN", (0, 0), (-1, -1), "TOP"),
          ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if head: st.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#166534")))
    t.setStyle(TableStyle(st)); return t


def img(name, w=16.5, caption=None):
    path = os.path.join(D, name)
    from PIL import Image as PI
    iw, ih = PI.open(path).size
    el = [Image(path, width=w * cm, height=w * cm * ih / iw)]
    if caption: el.append(P(caption, cap))
    return KeepTogether(el)


def footer(c, doc):
    c.setFont("DV", 8); c.setFillColor(colors.HexColor("#6b7280"))
    c.drawString(2 * cm, 1.2 * cm, "СРО · NoSQL · Вариант 1 · Каталог электроники (MongoDB)")
    c.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f"{doc.page}")


bench = json.load(open(os.path.join(D, "bench_result.json")))
S = []
# --- титул ---
S += [Spacer(1, 3 * cm), P("[Название вуза]", ParagraphStyle("t0", parent=body, alignment=TA_CENTER)),
      Spacer(1, 1.5 * cm),
      P("САМОСТОЯТЕЛЬНАЯ РАБОТА СТУДЕНТА (СРО)", ParagraphStyle("t1", fontName="DVB", fontSize=14, alignment=TA_CENTER, leading=20)),
      P("Дисциплина: «Проектирование и применение NoSQL-технологий»", ParagraphStyle("t2", parent=body, alignment=TA_CENTER)),
      Spacer(1, 1.2 * cm),
      P("Мини-проект, вариант 1:<br/><b>«Каталог электроники с быстрым поиском»</b>", ParagraphStyle("t3", fontName="DV", fontSize=18, alignment=TA_CENTER, leading=26)),
      Spacer(1, 0.6 * cm), P("Технология: MongoDB (Python, pymongo)", ParagraphStyle("t4", parent=body, alignment=TA_CENTER)),
      Spacer(1, 4 * cm),
      P("Выполнил: [ФИО студента], группа [группа]<br/>3 курс, ОП «Информационные системы»<br/>Преподаватель: [ФИО преподавателя]", ParagraphStyle("t5", parent=body, alignment=TA_CENTER, leading=18)),
      Spacer(1, 1 * cm), P("Алматы, 2026", ParagraphStyle("t6", parent=body, alignment=TA_CENTER)), PageBreak()]
# --- 1 цель ---
S += [P("1. Цель и постановка задачи", h1),
      P("Интернет-магазин электроники хранит тысячи карточек товаров с <b>разнородными характеристиками</b>: у смартфона важны объём оперативной памяти и ёмкость батареи, у телевизора — диагональ и тип матрицы, у наушников — шумоподавление и время работы. Покупателям нужен быстрый поиск и фильтрация (по категории, цене, характеристикам), а менеджерам — аналитика: средние цены, рейтинг брендов, стоимость складских остатков."),
      P("<b>Цель работы</b> — спроектировать и реализовать работающий прототип подсистемы хранения и поиска каталога на MongoDB, обосновать выбор NoSQL, смоделировать данные, реализовать CRUD, запросы и агрегации, а также показать влияние индексов на скорость запросов."),
      P("<b>Задачи:</b> (1) сформулировать требования и Access Patterns; (2) сравнить альтернативы и зафиксировать решение в ADR; (3) спроектировать схему документов и индексы; (4) реализовать код на Python, сгенерировать не менее 30 записей; (5) выполнить 8 запросов (из них 2 нетривиальных) и написать тесты; (6) сравнить запрос до и после создания индекса."),
      P("2. Требования", h1), P("Функциональные требования", h2),
      table([["№", "Требование"],
             ["FR1", "Создание карточки товара (sku, название, бренд, категория, цена, остаток, характеристики, теги) с валидацией."],
             ["FR2", "Получение карточки по артикулу (sku) и списка товаров категории."],
             ["FR3", "Изменение цены и остатка товара; остаток не может стать отрицательным."],
             ["FR4", "Удаление товара из каталога."],
             ["FR5", "Фильтрация по категории, диапазону цены и характеристикам (specs.*), по тегам и по части названия."],
             ["FR6", "Аналитика: средняя цена по категориям, рейтинг брендов, стоимость остатков, список заканчивающихся товаров."]],
            [1.6, 14.9]), Spacer(1, 6), P("Нефункциональные требования", h2),
      table([["№", "Требование"],
             ["NFR1", "Производительность: фильтр по цене на 20 000 карточек должен использовать индекс (IXSCAN) и просматривать только подходящие документы."],
             ["NFR2", "Целостность: артикул (sku) уникален; цена > 0; остаток — целое ≥ 0."],
             ["NFR3", "Воспроизводимость и безопасность: запуск по README, данные синтетические, секреты не хранятся в репозитории (.env.example)."],
             ["NFR4", "Расширяемость: новые категории с другими характеристиками добавляются без миграций схемы."]],
            [1.6, 14.9]), PageBreak()]
# --- 3 AP ---
S += [P("3. Предметная область и Access Patterns", h1),
      P("Сущности: <b>Категория</b> (справочник из 6 значений) и <b>Товар</b> (карточка). Основной сценарий нагрузки — чтение: фильтрация и сортировка; запись — редкое обновление цен и остатков."),
      table([["AP", "Описание", "Приоритет", "Ожидаемый результат", "Запрос"],
             ["AP1", "Товары категории в диапазоне цены, по возрастанию цены", "Высокий", "Список карточек, отсортированный по цене", "Q1"],
             ["AP2", "Фильтр по характеристикам (RAM, батарея)", "Высокий", "Подходящие смартфоны", "Q2"],
             ["AP3", "Поиск по части названия", "Средний", "До 10 карточек с совпадением", "Q3"],
             ["AP4", "Средняя цена по категориям", "Средний", "Строка на категорию: avg, число товаров", "Q4"],
             ["AP5", "Топ брендов по среднему рейтингу", "Средний", "До 5 брендов с ≥3 товарами", "Q5"],
             ["AP6", "Стоимость складских остатков по брендам", "Средний", "Бренды по убыванию суммы price×stock", "Q6"],
             ["AP7", "Товары в наличии по тегам, по рейтингу", "Высокий", "До 8 лучших товаров с нужными тегами", "Q7"],
             ["AP8", "Заканчивающиеся товары (остаток ≤ 3)", "Низкий", "Список для закупки", "Q8"]],
            [1.1, 5.6, 1.9, 6.0, 1.4]), PageBreak()]
# --- 4 альтернативы и ADR ---
S += [P("4. Сравнение альтернатив и ADR", h1),
      table([["Критерий", "MongoDB", "PostgreSQL", "Redis", "Cassandra", "Neo4j"],
             ["Разнородные характеристики", "Вложенный документ, гибко", "JSONB или EAV, сложнее", "Только как хеш/JSON, без запросов", "Жёсткая схема таблиц", "Свойства узлов, но не нужен граф"],
             ["Ad-hoc фильтры", "Да (индексы)", "Да", "Нет", "Только по ключу", "Cypher, избыточно"],
             ["Агрегации", "Aggregation pipeline", "SQL GROUP BY", "Нет", "Ограничены", "Есть, не основной сценарий"],
             ["Транзакции/JOIN", "Ограниченно (не нужны)", "Да", "Нет", "Нет", "Да (графовые)"],
             ["Вердикт", "<b>Выбран</b>", "Рабочая альтернатива", "Как кэш", "Не подходит", "Не подходит"]],
            [3.1, 3.0, 2.8, 2.6, 2.5, 2.5]), Spacer(1, 8),
      P("<b>ADR-001. Решение:</b> использовать MongoDB как основное хранилище каталога. Причины: (1) полиморфные характеристики товаров естественно ложатся во вложенный документ <font name='DVM'>specs</font>; (2) карточка читается одним запросом без JOIN; (3) фильтры по вложенным полям и aggregation pipeline покрывают все Access Patterns; (4) индексы подключаются без изменения схемы."),
      P("<b>Последствия:</b> плюсы — гибкость схемы, простота чтения, горизонтальное масштабирование (шардирование по sku или category); минусы — отсутствие JOIN (категория хранится ссылкой <font name='DVM'>category</font>, название подтягивается при необходимости), дублирование названия бренда, ответственность за валидацию на стороне приложения. Полный текст — <font name='DVM'>docs/ADR.md</font>."),
      img("architecture.png", 15.5, "Рис. 1. Архитектура прототипа"), PageBreak()]
# --- 5 схема ---
S += [P("5. Схема данных и архитектура", h1),
      P("<b>Коллекции.</b> <font name='DVM'>categories</font> — справочник (_id = «smartphones», name). <font name='DVM'>products</font> — карточки: <font name='DVM'>sku, name, brand, category, price, currency, stock, rating, tags[], specs{}, created_at</font>. Связь «категория → товары» реализована <b>ссылкой</b> (referencing), поскольку категорий мало и они меняются независимо; <font name='DVM'>specs</font> и <font name='DVM'>tags</font> <b>встроены</b> (embedding), так как читаются вместе с товаром и не используются отдельно."),
      img("data_model.png", 15.5, "Рис. 2. Модель данных"),
      P("Пример документа:"),
      Preformatted('''{ "sku": "PHN-00001", "name": "Aurora Pro 12", "brand": "Aurora",
  "category": "smartphones", "price": 378000, "currency": "KZT",
  "stock": 3, "rating": 3.6, "tags": ["5g", "gaming"],
  "specs": {"ram_gb": 4, "storage_gb": 512, "battery_mah": 4000, "screen_in": 6.1},
  "created_at": "2026-04-22T00:00:00" }''', code),
      P("<b>Индексы:</b> <font name='DVM'>sku</font> (unique) — выборка и защита от дублей; <font name='DVM'>{category:1, price:1}</font> — AP1 (равенство + диапазон + сортировка); <font name='DVM'>price</font> — диапазонные фильтры по всему каталогу; <font name='DVM'>stock</font> — AP8."),
      P("<b>Архитектура.</b> Приложение на Python состоит из слоя доступа <font name='DVM'>catalog.py</font> (CRUD и валидация), набора запросов <font name='DVM'>queries.py</font> и CLI-скриптов. Подключение выбирается переменной <font name='DVM'>DB_BACKEND</font>: реальный MongoDB через pymongo либо встроенный эмулятор <font name='DVM'>minimongo.py</font> (подмножество API для тестов без сервера)."),
      PageBreak()]
# --- 6 реализация ---
S += [P("6. Реализация и фрагменты кода", h1),
      P("<b>Валидация и создание</b> (src/catalog.py):"),
      Preformatted('''def validate_product(p):
    for f in REQUIRED:
        if f not in p: raise ValidationError(f"нет обязательного поля: {f}")
    if not isinstance(p["price"], (int, float)) or p["price"] <= 0:
        raise ValidationError("price должен быть > 0")
    if not isinstance(p["stock"], int) or p["stock"] < 0:
        raise ValidationError("stock должен быть целым >= 0")

def add_product(self, product):
    validate_product(product)
    return self.products.insert_one(product).inserted_id''', code),
      P("<b>Индексы</b> (src/catalog.py):"),
      Preformatted('''def setup_indexes(self):
    self.products.create_index("sku", unique=True)
    self.products.create_index([("category", 1), ("price", 1)])
    self.products.create_index("price")
    self.products.create_index("stock")''', code),
      P("<b>Изменение остатка</b> с защитой от отрицательных значений:"),
      Preformatted('''def adjust_stock(self, sku, delta):
    p = self.get_by_sku(sku)
    if p is None: return 0
    if p["stock"] + delta < 0:
        raise ValidationError("остаток не может быть отрицательным")
    return self.products.update_one({"sku": sku}, {"$inc": {"stock": delta}}).modified_count''', code),
      P("<b>Генерация данных.</b> Скрипт <font name='DVM'>scripts/seed.py</font> создаёт 48 синтетических товаров (по 8 в каждой из 6 категорий) с детерминированным генератором (seed=42): реальные персональные данные не используются, бренды вымышленные. Для замеров индекса <font name='DVM'>bench_index.py</font> создаёт 20 000 документов."),
      img("screenshots/01_seed.png", 16, "Рис. 3. Заполнение БД: 6 категорий, 48 товаров, индексы"),
      img("screenshots/04_crud.png", 14, "Рис. 4. Демонстрация CRUD, валидации и уникальности sku"), PageBreak()]
# --- 7 запросы ---
S += [P("7. Запросы и результаты", h1),
      P("Реализовано 8 демонстрационных запросов; <b>нетривиальные</b> — Q5 (многостадийный pipeline: $group → $match по результату группировки → $project/$round → $sort → $limit) и Q6 (вычисляемое выражение $multiply внутри $group)."),
      table([["Запрос", "Операция", "Что демонстрирует"],
             ["Q1", "find + диапазон + sort", "составной индекс {category, price}"],
             ["Q2", "find по вложенным полям", "фильтры specs.ram_gb, specs.battery_mah"],
             ["Q3", "$regex", "поиск по части названия"],
             ["Q4", "$group + $avg", "средняя цена по категориям"],
             ["Q5", "$group, $match, $sort, $limit", "рейтинг брендов, фильтр после группировки"],
             ["Q6", "$group + $sum{$multiply}", "стоимость остатков"],
             ["Q7", "$in по массиву tags + sort", "поиск по тегам, наличие"],
             ["Q8", "find + sort по 2 полям", "закупка: остаток ASC, цена DESC"]], [1.6, 5.4, 9.5]), Spacer(1, 6),
      img("screenshots/02_queries_q1_q4.png", 16, "Рис. 5. Результаты запросов Q1–Q4 (вывод scripts/run_queries.py)"),
      img("screenshots/03_queries_q5_q8.png", 16, "Рис. 6. Результаты запросов Q5–Q8"), PageBreak()]
# --- 8 индекс ---
S += [P("8. Сравнение запроса до и после индекса", h1),
      P(f"Запрос: <font name='DVM'>db.products.find({{price: {{$gte: 300000, $lte: 310000}}}})</font> на {bench['n']:,} документов. "
        f"Без индекса планировщик выбирает {bench['before']['stage']} и просматривает {bench['before']['docsExamined']:,} документов (среднее {bench['before']['avg_ms']} мс). "
        f"После <font name='DVM'>create_index('price')</font> — {bench['after']['stage']}, просмотрено {bench['after']['docsExamined']:,} документов (среднее {bench['after']['avg_ms']} мс); число возвращённых документов одинаково ({bench['after']['nReturned']})."),
      P("<b>Важное замечание.</b> Замеры выше получены на встроенном эмуляторе (backend: emulator), так как в среде подготовки отчёта не было сервера MongoDB. Это иллюстрирует принцип работы индекса (сокращение числа просматриваемых документов), но абсолютное время на реальном MongoDB будет другим. Перед защитой команду <font name='DVM'>DB_BACKEND=mongo python scripts/bench_index.py 20000</font> следует выполнить на реальном сервере и при необходимости заменить значения/скриншот."),
      img("bench_chart.png", 13.5, "Рис. 7. Просмотрено документов и время до/после индекса"),
      img("screenshots/06_bench.png", 15, "Рис. 8. Вывод scripts/bench_index.py"), PageBreak()]
# --- 9 тесты ---
S += [P("9. Тестирование", h1),
      table([["Тест", "Проверяет"],
             ["test_01", "после заполнения в БД не менее 30 записей"],
             ["test_02", "цикл CRUD: создать → прочитать → изменить цену → удалить"],
             ["test_03", "валидация (отрицательная цена) и уникальность sku"],
             ["test_04", "корректность фильтра по цене и порядка сортировки (Q1)"],
             ["test_05", "агрегат $avg совпадает с ручным расчётом по сгенерированным данным"],
             ["test_06", "все 8 запросов выполняются и возвращают данные"],
             ["test_07", "индекс меняет план COLLSCAN → IXSCAN и уменьшает docsExamined при том же результате"]], [2.4, 14.1]),
      Spacer(1, 6), img("screenshots/05_tests.png", 16, "Рис. 9. Результат запуска тестов: 7 тестов, OK"), PageBreak()]
# --- 10 ограничения, выводы ---
S += [P("10. Ограничения", h1),
      P("• Прототип работает с одним узлом MongoDB; репликация и шардирование не настраивались.<br/>"
        "• Эмулятор minimongo.py покрывает только используемое подмножество API и использует упрощённый планировщик; для итоговых замеров нужен реальный MongoDB.<br/>"
        "• Полнотекстовый поиск реализован через $regex (без индекса); для production следует использовать text/Atlas Search.<br/>"
        "• Название категории в карточке не дублируется — для вывода «Смартфоны» нужен дополнительный запрос или $lookup.<br/>"
        "• Данные синтетические, цены в тенге (KZT) условные; многопользовательская конкурентность не исследовалась."),
      P("11. Выводы", h1),
      P("Разработан и протестирован прототип каталога электроники на MongoDB: модель «документ-товар» с встроенными характеристиками позволила хранить разнородные категории в одной коллекции, а aggregation pipeline покрыл аналитические сценарии (средняя цена, рейтинг брендов, стоимость остатков). Выбор MongoDB обоснован в ADR и сравнением с PostgreSQL, Redis, Cassandra и Neo4j. Индекс по цене сократил число просматриваемых документов в 100 раз на выборке 20 000 карточек (в эмуляторе); 7 автотестов подтверждают корректность CRUD, запросов и работы индекса."),
      P("<b>Что можно улучшить:</b> добавить text-индекс и $lookup для названий категорий, кэширование популярных запросов в Redis, шардирование по category."),
      P("12. Ссылка на GitHub", h1), P("[вставьте ссылку на репозиторий: https://github.com/&lt;user&gt;/electronics-catalog]")]

doc = SimpleDocTemplate(os.path.join(D, "report.pdf"), pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=2 * cm,
                        title="СРО NoSQL — Вариант 1 — Каталог электроники", author="[ФИО студента]")
doc.build(S, onFirstPage=lambda c, d: None, onLaterPages=footer)
print("report built")
