"""Запуск 8 демонстрационных запросов: python scripts/run_queries.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.db import get_db
from src.catalog import Catalog
from src.queries import QUERIES


def fmt(d):
    if "sku" in d:
        s = d.get("specs", {})
        extra = f"ram={s['ram_gb']} bat={s['battery_mah']}" if "battery_mah" in s else f"stock={d['stock']} rating={d['rating']}"
        return f"  {d['sku']:<10}{d['name']:<18}{d['category']:<13}{d['price']:>9,} KZT  {extra}"
    return "  " + "  ".join(f"{k}={v}" for k, v in d.items())


def main(limit=4):
    db, backend = get_db()
    if db["products"].count_documents({}) == 0:
        c = Catalog(db); c.setup_indexes(); c.seed()
    print(f"backend: {backend}   products: {db['products'].count_documents({})}\n")
    for q in QUERIES:
        res = list(q["run"](db))
        print(f"[{q['id']}/{q['ap']}] {q['title']}")
        print(f"  db.products.{q['shell']}")
        print(f"  -> {len(res)} док.")
        for d in res[:limit]:
            print(fmt(d))
        print()


if __name__ == "__main__":
    main()
