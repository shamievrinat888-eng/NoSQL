"""Заполнение БД синтетическими данными: python scripts/seed.py [N]"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.db import get_db
from src.catalog import Catalog

if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 48
    db, backend = get_db()
    db["products"].delete_many({}); db["categories"].delete_many({})
    cat = Catalog(db); cat.setup_indexes()
    total = cat.seed(n)
    print(f"backend: {backend}")
    print(f"categories: {db['categories'].count_documents({})}")
    print(f"products inserted: {total}")
    print("indexes:", ", ".join(db['products'].index_information().keys()))
    print("sample:", cat.get_by_sku("PHN-00001"))
