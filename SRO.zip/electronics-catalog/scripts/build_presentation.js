// Сборка docs/presentation.pptx (pptxgenjs). Запуск: node scripts/build_presentation.js
const pptxgen = require("pptxgenjs");
const sharp = require("sharp");
const fs = require("fs");
const path = require("path");
const { applyTheme } = require("/mnt/skills/public/pptx/scripts/apply_theme.js");

const ROOT = path.resolve(__dirname, "..");
const D = path.join(ROOT, "docs");
const bench = JSON.parse(fs.readFileSync(path.join(D, "bench_result.json")));

const THEME = {
  name: "ElectronicsCatalog", headFontFace: "Calibri", bodyFontFace: "Calibri",
  colors: { dk1: "1F2937", lt1: "FFFFFF", dk2: "0B2E1F", lt2: "F1F5F2", accent1: "13AA52", accent2: "F59E0B",
            accent3: "3B82F6", accent4: "EF4444", accent5: "6B7280", accent6: "8B5CF6", hlink: "13AA52", folHlink: "6B7280" },
};

async function dims(p) { const m = await sharp(p).metadata(); return m.width / m.height; }

(async () => {
  const pres = new pptxgen();
  pres.layout = "LAYOUT_16x9";
  pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
  pres.title = "Каталог электроники (MongoDB) — СРО NoSQL, вариант 1";
  const C = pres.SchemeColor;

  pres.defineSlideMaster({
    title: "CONTENT", background: { color: "FFFFFF" },
    objects: [{ placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9, h: 0.7, fontSize: 26, bold: true, color: C.text2, margin: 0, valign: "middle" }, text: "" } }],
    slideNumber: { x: 9.2, y: 5.25, w: 0.5, h: 0.25, fontSize: 9, color: "6B7280" },
  });
  pres.defineSlideMaster({ title: "DARK", background: { color: C.text2 }, objects: [] });

  const img = async (s, rel, x, y, w, name) => {
    const p = path.join(D, rel); const ar = await dims(p);
    s.addImage({ path: p, x, y, w, h: w / ar, objectName: name }); return w / ar;
  };
  const card = (s, x, y, w, h, name, accent = C.accent1) => {
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: C.background2 }, line: { color: accent, width: 1.25 }, objectName: name });
  };

  // 1. Титул
  pres.addSection({ title: "Введение" });
  let s = pres.addSlide({ masterName: "DARK", sectionTitle: "Введение" });
  s.addShape(pres.shapes.OVAL, { x: 7.6, y: 0.9, w: 1.7, h: 1.7, fill: { color: C.accent1 }, line: { color: C.accent1 }, objectName: "motif-circle" });
  s.addText("DB", { x: 7.6, y: 0.9, w: 1.7, h: 1.7, align: "center", valign: "middle", fontSize: 40, bold: true, color: C.background1, isTextBox: true, objectName: "motif-text" });
  s.addText("Каталог электроники\nс быстрым поиском", { x: 0.6, y: 1.2, w: 6.8, h: 1.7, fontSize: 36, bold: true, color: C.background1, margin: 0, valign: "top", isTextBox: true, objectName: "title" });
  s.addText("MongoDB · Python · СРО, вариант 1", { x: 0.6, y: 3.0, w: 7, h: 0.4, fontSize: 18, color: C.accent1, margin: 0, isTextBox: true, objectName: "subtitle" });
  s.addText("[ФИО студента] · группа [группа] · «Проектирование и применение NoSQL-технологий»", { x: 0.6, y: 4.6, w: 8.8, h: 0.4, fontSize: 12, color: C.background2, margin: 0, isTextBox: true, objectName: "author" });
  s.addNotes("Представиться, назвать тему: каталог электроники на MongoDB. Время: 20 секунд.");

  // 2. Проблема и цель
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Введение" });
  s.addText("Проблема и цель", { placeholder: "title" });
  const probs = [["Разные товары — разные поля", "У смартфона RAM и батарея, у ТВ диагональ и матрица"], ["Быстрые фильтры", "Категория + цена + характеристики на тысячах карточек"], ["Аналитика", "Средняя цена, рейтинг брендов, стоимость остатков"]];
  probs.forEach((p, i) => {
    card(s, 0.5, 1.2 + i * 1.15, 5.3, 1.0, `problem-card-${i + 1}`);
    s.addText([{ text: p[0], options: { bold: true, fontSize: 15, color: C.text2, breakLine: true } }, { text: p[1], options: { fontSize: 12, color: C.text1 } }], { x: 0.7, y: 1.25 + i * 1.15, w: 4.9, h: 0.9, valign: "middle", margin: 0, isTextBox: true, objectName: `problem-text-${i + 1}` });
  });
  s.addShape(pres.shapes.RECTANGLE, { x: 6.2, y: 1.2, w: 3.3, h: 3.3, fill: { color: C.text2 }, line: { color: C.text2 }, objectName: "goal-panel" });
  s.addText([{ text: "Цель", options: { bold: true, fontSize: 18, color: C.accent1, breakLine: true } },
             { text: "Работающий прототип каталога на MongoDB: CRUD, фильтры, агрегации, индексы и обоснование выбора NoSQL.", options: { fontSize: 14, color: C.background1 } }],
            { x: 6.4, y: 1.35, w: 2.9, h: 3.0, valign: "top", margin: 0, isTextBox: true, objectName: "goal-text" });

  // 3. Требования
  pres.addSection({ title: "Анализ и выбор" });
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Анализ и выбор" });
  s.addText("Требования: 6 функциональных, 4 нефункциональных", { placeholder: "title" });
  card(s, 0.5, 1.2, 5.0, 3.7, "fr-card");
  s.addText("Функциональные", { x: 0.7, y: 1.3, w: 4.6, h: 0.35, fontSize: 15, bold: true, color: C.text2, margin: 0, isTextBox: true, objectName: "fr-title" });
  s.addText(["Создание карточки с валидацией", "Чтение по sku, список категории", "Изменение цены и остатка", "Удаление товара", "Фильтры: цена, specs, теги, название", "Аналитика и отчёты (8 Access Patterns)"].map((t, i, a) => ({ text: t, options: { bullet: true, breakLine: i < a.length - 1 } })),
            { x: 0.7, y: 1.7, w: 4.6, h: 3.1, fontSize: 13, color: C.text1, paraSpaceAfter: 6, valign: "top", margin: 0, isTextBox: true, objectName: "fr-list" });
  card(s, 5.8, 1.2, 3.7, 3.7, "nfr-card", C.accent2);
  s.addText("Нефункциональные", { x: 6.0, y: 1.3, w: 3.3, h: 0.35, fontSize: 15, bold: true, color: C.text2, margin: 0, isTextBox: true, objectName: "nfr-title" });
  s.addText(["Индекс вместо полного скана (NFR1)", "Целостность: уникальный sku, цена > 0 (NFR2)", "Воспроизводимость, без секретов (NFR3)", "Новые категории без миграций (NFR4)"].map((t, i, a) => ({ text: t, options: { bullet: true, breakLine: i < a.length - 1 } })),
            { x: 6.0, y: 1.7, w: 3.3, h: 3.1, fontSize: 13, color: C.text1, paraSpaceAfter: 6, valign: "top", margin: 0, isTextBox: true, objectName: "nfr-list" });

  // 4. Выбор технологии
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Анализ и выбор" });
  s.addText("Выбор технологии: почему MongoDB", { placeholder: "title" });
  const hd = (t) => ({ text: t, options: { bold: true, color: "FFFFFF", fill: { color: "0B2E1F" }, align: "center" } });
  const ok = (t) => ({ text: t, options: { align: "center", color: "166534", bold: true } });
  const mid = (t) => ({ text: t, options: { align: "center", color: "92400E" } });
  const no = (t) => ({ text: t, options: { align: "center", color: "B91C1C" } });
  s.addTable([
    [hd("Критерий"), hd("MongoDB"), hd("PostgreSQL"), hd("Redis"), hd("Cassandra"), hd("Neo4j")],
    ["Разнородные поля товаров", ok("вложенный документ"), mid("JSONB / EAV"), no("нет"), no("жёсткая схема"), mid("не нужен граф")],
    ["Ad-hoc фильтры", ok("да"), ok("да"), no("нет"), no("по ключу"), mid("избыточно")],
    ["Агрегации", ok("pipeline"), ok("GROUP BY"), no("нет"), mid("ограничены"), mid("не основное")],
    ["Чтение карточки без JOIN", ok("да"), mid("JOIN"), ok("да"), ok("да"), mid("обход")],
    [{ text: "Вердикт", options: { bold: true } }, ok("выбран"), mid("альтернатива"), mid("как кэш"), no("не подходит"), no("не подходит")],
  ].map((r, i) => i === 0 ? r : r.map((c, j) => typeof c === "string" ? { text: c, options: { bold: j === 0 } } : c)),
    { x: 0.5, y: 1.2, w: 9, colW: [2.4, 1.5, 1.3, 1.2, 1.4, 1.2], fontSize: 12, color: "1F2937", border: { type: "solid", color: "9CA3AF", pt: 0.5 }, rowH: 0.5, valign: "middle", objectName: "tech-table" });
  s.addText("ADR-001: гибкая схема, одна карточка = один документ, фильтры и агрегации «из коробки», индексы без смены схемы.", { x: 0.5, y: 4.4, w: 9, h: 0.6, fontSize: 14, color: C.text2, bold: true, margin: 0, isTextBox: true, objectName: "adr-note" });

  // 5. Модель данных
  pres.addSection({ title: "Реализация" });
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Реализация" });
  s.addText("Модель данных", { placeholder: "title" });
  await img(s, "data_model.png", 0.4, 1.3, 6.0, "data-model-image");
  card(s, 6.7, 1.3, 2.8, 3.4, "index-card", C.accent3);
  s.addText([{ text: "Индексы", options: { bold: true, fontSize: 15, color: C.text2, breakLine: true } },
             { text: "sku (unique)", options: { bullet: true, breakLine: true } }, { text: "{category, price}", options: { bullet: true, breakLine: true } },
             { text: "price", options: { bullet: true, breakLine: true } }, { text: "stock", options: { bullet: true, breakLine: true } },
             { text: "Embedding: specs, tags. Referencing: category.", options: { fontSize: 12, color: C.accent5 } }],
            { x: 6.9, y: 1.4, w: 2.4, h: 3.2, fontSize: 13, color: C.text1, paraSpaceAfter: 5, valign: "top", margin: 0, isTextBox: true, objectName: "index-text" });

  // 6. Архитектура
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Реализация" });
  s.addText("Архитектура прототипа", { placeholder: "title" });
  const hA = await img(s, "architecture.png", 0.9, 1.15, 8.2, "architecture-image");
  s.addText("Основной режим — MongoDB через pymongo; эмулятор — запасной режим без сервера (тесты/CI).", { x: 0.9, y: 1.25 + hA, w: 8.2, h: 0.35, fontSize: 12, color: C.accent5, align: "center", margin: 0, isTextBox: true, objectName: "arch-caption" });

  // 7. Реализация
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Реализация" });
  s.addText("Реализация: код и CRUD", { placeholder: "title" });
  s.addShape(pres.shapes.RECTANGLE, { x: 0.5, y: 1.2, w: 4.6, h: 3.6, fill: { color: "1E1E2E" }, line: { color: "1E1E2E" }, objectName: "code-panel" });
  s.addText(
    "def validate_product(p):\n    for f in REQUIRED:\n        if f not in p:\n            raise ValidationError(f)\n    if p[\"price\"] <= 0:\n        raise ValidationError(\"price > 0\")\n\ndef setup_indexes(self):\n    c = self.products\n    c.create_index(\"sku\", unique=True)\n    c.create_index([(\"category\",1),\n                    (\"price\",1)])\n    c.create_index(\"price\")",
    { x: 0.65, y: 1.3, w: 4.3, h: 3.4, fontFace: "Consolas", fontSize: 10.5, color: "CDD6F4", valign: "top", margin: 0, isTextBox: true, objectName: "code-text" });
  await img(s, "screenshots/s_crud.png", 5.3, 1.2, 4.3, "crud-screenshot");
  s.addText("48 синтетических товаров · CRUD · валидация · уникальный sku", { x: 5.3, y: 4.55, w: 4.3, h: 0.5, fontSize: 12, color: C.accent5, margin: 0, isTextBox: true, objectName: "impl-caption" });

  // 8. Запросы и тесты
  pres.addSection({ title: "Результаты" });
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Результаты" });
  s.addText("Запросы и тесты", { placeholder: "title" });
  const h1 = await img(s, "screenshots/s_queries.png", 0.4, 1.15, 5.0, "queries-screenshot");
  await img(s, "screenshots/s_tests.png", 5.6, 1.15, 4.0, "tests-screenshot");
  s.addText("8 запросов (Q5, Q6 — нетривиальные pipeline)", { x: 0.4, y: 1.25 + h1, w: 5.0, h: 0.3, fontSize: 12, color: C.text2, bold: true, margin: 0, isTextBox: true, objectName: "queries-caption" });
  s.addText("7 тестов: CRUD, валидация, фильтры, агрегаты, индекс", { x: 5.6, y: 4.5, w: 4.0, h: 0.5, fontSize: 12, color: C.text2, bold: true, margin: 0, isTextBox: true, objectName: "tests-caption" });

  // 9. Индекс
  s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Результаты" });
  s.addText("Запрос до и после индекса", { placeholder: "title" });
  await img(s, "bench_chart.png", 0.4, 1.3, 5.6, "bench-chart");
  const speed = (bench.before.avg_ms / bench.after.avg_ms).toFixed(1);
  card(s, 6.3, 1.3, 3.2, 1.2, "stat-docs");
  s.addText([{ text: `${bench.before.docsExamined.toLocaleString("ru-RU")} → ${bench.after.docsExamined}`, options: { bold: true, fontSize: 24, color: C.accent1, breakLine: true } }, { text: "просмотрено документов", options: { fontSize: 12, color: C.text1 } }], { x: 6.4, y: 1.35, w: 3.0, h: 1.1, valign: "middle", margin: 0, isTextBox: true, objectName: "stat-docs-text" });
  card(s, 6.3, 2.7, 3.2, 1.2, "stat-time", C.accent2);
  s.addText([{ text: `${bench.before.avg_ms} → ${bench.after.avg_ms} мс`, options: { bold: true, fontSize: 24, color: C.accent2, breakLine: true } }, { text: `ускорение ×${speed}`, options: { fontSize: 12, color: C.text1 } }], { x: 6.4, y: 2.75, w: 3.0, h: 1.1, valign: "middle", margin: 0, isTextBox: true, objectName: "stat-time-text" });
  s.addText(`COLLSCAN → IXSCAN на ${bench.n.toLocaleString("ru-RU")} документах. Замер выполнен на эмуляторе; на защите повторить с DB_BACKEND=mongo.`, { x: 0.5, y: 4.55, w: 9, h: 0.5, fontSize: 11, color: C.accent5, margin: 0, isTextBox: true, objectName: "bench-note" });

  // 10. Выводы
  pres.addSection({ title: "Итоги" });
  s = pres.addSlide({ masterName: "DARK", sectionTitle: "Итоги" });
  s.addText("Ограничения и выводы", { x: 0.6, y: 0.4, w: 8.8, h: 0.7, fontSize: 28, bold: true, color: C.background1, margin: 0, isTextBox: true, objectName: "title" });
  s.addText("Выводы", { x: 0.6, y: 1.3, w: 4.2, h: 0.4, fontSize: 18, bold: true, color: C.accent1, margin: 0, isTextBox: true, objectName: "conclusions-title" });
  s.addText(["Документная модель хранит разные категории в одной коллекции", "Pipeline закрыл все аналитические сценарии", "Индекс сократил просмотр документов в 100 раз"].map((t, i, a) => ({ text: t, options: { bullet: true, breakLine: i < a.length - 1 } })),
            { x: 0.6, y: 1.75, w: 4.2, h: 2.4, fontSize: 14, color: C.background1, paraSpaceAfter: 8, valign: "top", margin: 0, isTextBox: true, objectName: "conclusions-list" });
  s.addText("Ограничения", { x: 5.2, y: 1.3, w: 4.2, h: 0.4, fontSize: 18, bold: true, color: C.accent2, margin: 0, isTextBox: true, objectName: "limits-title" });
  s.addText(["Один узел, без репликации и шардинга", "Поиск по названию через $regex", "Замеры индекса — на эмуляторе"].map((t, i, a) => ({ text: t, options: { bullet: true, breakLine: i < a.length - 1 } })),
            { x: 5.2, y: 1.75, w: 4.2, h: 2.4, fontSize: 14, color: C.background1, paraSpaceAfter: 8, valign: "top", margin: 0, isTextBox: true, objectName: "limits-list" });
  s.addText("GitHub: [ссылка на репозиторий electronics-catalog]", { x: 0.6, y: 4.6, w: 8.8, h: 0.4, fontSize: 14, color: C.accent1, margin: 0, isTextBox: true, objectName: "github-link" });

  const out = path.join(D, "presentation.pptx");
  await pres.writeFile({ fileName: out });
  await applyTheme(out, THEME);
  console.log("presentation built");
})();
