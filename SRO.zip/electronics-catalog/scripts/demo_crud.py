"""Демонстрация CRUD: python scripts/demo_crud.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.db import get_db
from src.catalog import Catalog, ValidationError

db, backend = get_db()
cat = Catalog(db); cat.setup_indexes(); cat.seed()
print(f"backend: {backend}")
new = {"sku": "DEMO-00001", "name": "Aurora Pro 99", "brand": "Aurora", "category": "smartphones",
       "price": 299000, "stock": 10, "rating": 4.6, "tags": ["5g"], "specs": {"ram_gb": 8}}
print("CREATE  ->", cat.add_product(new))
print("READ    ->", {k: cat.get_by_sku("DEMO-00001")[k] for k in ("sku", "name", "price", "stock")})
print("UPDATE price 299000 -> 279000, modified:", cat.update_price("DEMO-00001", 279000))
print("UPDATE stock -4, modified:", cat.adjust_stock("DEMO-00001", -4))
print("READ    ->", {k: cat.get_by_sku("DEMO-00001")[k] for k in ("sku", "price", "stock")})
try:
    cat.update_price("DEMO-00001", -5)
except ValidationError as e:
    print("VALIDATION ->", e)
try:
    cat.add_product(dict(new))
except Exception as e:
    print("DUPLICATE  ->", type(e).__name__, "(sku уникален)")
print("DELETE  -> deleted:", cat.delete_product("DEMO-00001"))
print("READ    ->", cat.get_by_sku("DEMO-00001"))
