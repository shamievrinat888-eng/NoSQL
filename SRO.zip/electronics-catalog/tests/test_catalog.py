import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.db import get_db, explain_summary
from src.catalog import Catalog, ValidationError
from src.queries import QUERIES
from src.seed_data import generate_products


def fresh():
    db, _ = get_db("emulator")
    c = Catalog(db); c.setup_indexes(); c.seed(48)
    return db, c


class CatalogTests(unittest.TestCase):
    def setUp(self):
        self.db, self.cat = fresh()

    def test_01_seed_has_at_least_30_records(self):
        self.assertGreaterEqual(self.db["products"].count_documents({}), 30)

    def test_02_crud_cycle(self):
        p = {"sku": "T-1", "name": "Test Pro 1", "brand": "Test", "category": "tv", "price": 1000, "stock": 5}
        self.cat.add_product(p)
        self.assertEqual(self.cat.get_by_sku("T-1")["price"], 1000)
        self.assertEqual(self.cat.update_price("T-1", 900), 1)
        self.assertEqual(self.cat.get_by_sku("T-1")["price"], 900)
        self.assertEqual(self.cat.delete_product("T-1"), 1)
        self.assertIsNone(self.cat.get_by_sku("T-1"))

    def test_03_validation_and_unique_sku(self):
        with self.assertRaises(ValidationError):
            self.cat.add_product({"sku": "X", "name": "n", "brand": "b", "category": "tv", "price": -1, "stock": 1})
        sku = generate_products(1)[0]["sku"]
        with self.assertRaises(Exception):
            self.cat.add_product(dict(generate_products(1)[0], sku=sku))

    def test_04_price_filter_is_correct(self):
        res = list(QUERIES[0]["run"](self.db))
        self.assertTrue(res)
        self.assertTrue(all(150_000 <= d["price"] <= 400_000 and d["category"] == "smartphones" for d in res))
        self.assertEqual([d["price"] for d in res], sorted(d["price"] for d in res))

    def test_05_avg_price_matches_manual_calc(self):
        agg = {d["_id"]: d for d in self.db["products"].aggregate(
            [{"$group": {"_id": "$category", "avg_price": {"$avg": "$price"}}}])}
        for cat, row in agg.items():
            prices = [p["price"] for p in generate_products(48) if p["category"] == cat]
            self.assertAlmostEqual(row["avg_price"], sum(prices) / len(prices), places=6)

    def test_06_all_queries_run_and_return_data(self):
        self.assertGreaterEqual(len(QUERIES), 8)
        for q in QUERIES:
            self.assertTrue(len(list(q["run"](self.db))) > 0, q["id"])

    def test_07_index_reduces_docs_examined(self):
        db, _ = get_db("emulator")
        db["products"].insert_many(generate_products(3000, seed=3))
        flt = {"price": {"$gte": 300_000, "$lte": 305_000}}
        before = explain_summary(db["products"].find(flt))
        db["products"].create_index("price")
        after = explain_summary(db["products"].find(flt))
        self.assertEqual(before["stage"], "COLLSCAN")
        self.assertEqual(after["stage"], "IXSCAN")
        self.assertLess(after["docsExamined"], before["docsExamined"])
        self.assertEqual(before["nReturned"], after["nReturned"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
